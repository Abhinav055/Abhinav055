# summer_training_mlops_2021
Aspiring MLOps Engineer || Technical Helping Guy || MLOPS 🧠 || DEVOPS(🐳☸👩🏻‍🍳)|| Learner@ IIEC &amp; LW || ML || DL || MLOPS Summer 2021 Intern - at LW || GLA universit
